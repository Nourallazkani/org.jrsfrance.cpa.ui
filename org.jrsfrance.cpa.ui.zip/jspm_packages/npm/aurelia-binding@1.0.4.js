define(["npm:aurelia-binding@1.0.4/aurelia-binding"], function(main) {
  return main;
});