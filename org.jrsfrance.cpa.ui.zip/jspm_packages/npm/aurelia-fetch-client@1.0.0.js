define(["npm:aurelia-fetch-client@1.0.0/aurelia-fetch-client"], function(main) {
  return main;
});