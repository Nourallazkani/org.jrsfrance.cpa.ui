define(["npm:aurelia-framework@1.0.3/aurelia-framework"], function(main) {
  return main;
});