define(["npm:aurelia-loader-default@1.0.0/aurelia-loader-default"], function(main) {
  return main;
});