define(["npm:aurelia-loader@1.0.0/aurelia-loader"], function(main) {
  return main;
});