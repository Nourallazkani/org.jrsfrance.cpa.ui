define(["npm:aurelia-logging@1.0.0/aurelia-logging"], function(main) {
  return main;
});