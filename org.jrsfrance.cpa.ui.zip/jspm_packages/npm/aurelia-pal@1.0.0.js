define(["npm:aurelia-pal@1.0.0/aurelia-pal"], function(main) {
  return main;
});