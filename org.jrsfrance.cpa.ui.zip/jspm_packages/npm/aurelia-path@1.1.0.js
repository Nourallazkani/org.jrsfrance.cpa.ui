define(["npm:aurelia-path@1.1.0/aurelia-path"], function(main) {
  return main;
});