define(["npm:aurelia-polyfills@1.1.1/aurelia-polyfills"], function(main) {
  return main;
});