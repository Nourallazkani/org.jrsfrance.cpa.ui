define(["npm:aurelia-route-recognizer@1.0.0/aurelia-route-recognizer"], function(main) {
  return main;
});