define(["npm:aurelia-templating-binding@1.0.0/aurelia-templating-binding"], function(main) {
  return main;
});