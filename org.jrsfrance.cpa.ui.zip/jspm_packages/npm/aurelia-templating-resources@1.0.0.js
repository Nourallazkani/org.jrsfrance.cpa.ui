define(["npm:aurelia-templating-resources@1.0.0/aurelia-templating-resources"], function(main) {
  return main;
});