define(["npm:aurelia-templating-router@1.0.0/aurelia-templating-router"], function(main) {
  return main;
});