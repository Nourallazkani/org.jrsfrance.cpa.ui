/* */ 
module.exports = require('./$.global').document && document.documentElement;
