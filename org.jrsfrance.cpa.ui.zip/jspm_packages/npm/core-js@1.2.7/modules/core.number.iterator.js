/* */ 
'use strict';
require('./$.iter-define')(Number, 'Number', function(iterated) {
  this._l = +iterated;
  this._i = 0;
}, function() {
  var i = this._i++,
      done = !(i < this._l);
  return {
    done: done,
    value: done ? undefined : i
  };
});
