/* */ 
var $export = require('./$.export');
$export($export.S, 'Math', {sign: require('./$.math-sign')});
