/* */ 
module.exports = require('./web/index');
